import machine, neopixel
import time
# number of pixels
n = 12
# strip control gpio
p = 14
np = neopixel.NeoPixel(machine.Pin(p), n)
tm =0.05
def clear():
  for i in range(n):
    np[i] = (0, 0, 0)
    np.write()

while True:
  # ciclo >>>
  for i in range(0,6):
    dr = i
    iz = 11-i
    if dr > 0:
      np[dr-1] = (0, 0, 0)
    np[dr] = (50, 0, 0)
    if 1-i <= 0:
      np[12-i] = (0, 0, 0)
    np[iz] = (50, 0, 0)
    np.write()
    time.sleep(tm)
  #ciclo <<
  for i in range(0,6):
    dr = 5-i
    iz = i+6
    if dr + 1 <= 5:
      np[dr + 1] = (0, 0, 0)
    np[dr] = (50, 0, 0)

    if iz - 1 > 5:
      np[iz - 1] = (0, 0, 0)
    np[iz] = (50, 0, 0)
    np.write()
    time.sleep(tm)
   
  clear()
  time.sleep(tm)
