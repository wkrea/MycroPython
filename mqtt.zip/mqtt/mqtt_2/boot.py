

# Complete project details at https://RandomNerdTutorials.com

import time
from umqttsimple import MQTTClient
import ubinascii
import machine
from machine import Pin
import micropython
import network
import esp
esp.osdebug(None)
import gc
gc.collect()

ssid = 'HUAWEI'
password = '+36+wifi'
mqtt_server = 'aci-mosquitto-test.eastus.azurecontainer.io'

client_id = ubinascii.hexlify(machine.unique_id())
topic_sub = b'esp8266'
topic_pub = b'confirmacion/{}'.format(client_id)


last_message = 0
message_interval = 5
counter = 0

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

led = Pin(2, Pin.OUT)

while station.isconnected() == False:
  pass

print('Connection successful')
print(station.ifconfig())


