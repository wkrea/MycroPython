# Complete project details at https://RandomNerdTutorials.com
import machine, neopixel
import time
# number of pixels
n = 12
# strip control gpio
p = 14
np = neopixel.NeoPixel(machine.Pin(p), n)
tm =0.5
def clear():
  for i in range(n):
    np[i] = (0, 0, 0)
    np.write()
    
# set strip color
def set_color(r, g, b):
 for i in range(n):
   np[i] = (r, g, b)
   np.write()
    
def sub_cb(topic, msg):
  print((topic, msg))
  if topic == b'neopixel':
    clear()
    val = 50
    for j in range(n):
      if msg == b'red':
        np[j] = (val, 0, 0)
      elif msg == b'green':
        np[j] = (0, val, 0)
      elif msg == b'blue':
        np[j] = (0, 0, val)
      elif msg == b'purple':
        np[j] = (val, 0, val)
      elif msg == b'yellow':
        np[j] = (val, val, 0)
      elif msg == b'teal':
        np[j] = (0, val, val)
      elif msg == b'white':
        np[j] = (val, val, val)
    np.write()
    time.sleep(10)
      

def connect_and_subscribe():
  global client_id, mqtt_server, topic_sub
  client = MQTTClient(client_id, mqtt_server)
  client.set_callback(sub_cb)
  client.connect()
  client.subscribe(topic_sub)
  print('Connected to %s MQTT broker, subscribed to %s topic' % (mqtt_server, topic_sub))
  return client

def restart_and_reconnect():
  print('Failed to connect to MQTT broker. Reconnecting...')
  time.sleep(10)
  machine.reset()

try:
  client = connect_and_subscribe()
except OSError as e:
  restart_and_reconnect()

while True:
  try:
    client.check_msg()
    if (time.time() - last_message) > message_interval:
      clear()
      last_message = time.time()
  except OSError as e:
    restart_and_reconnect()


