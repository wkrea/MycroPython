import machine, neopixel
import time
# number of pixels
n = 12
# strip control gpio
p = 14
np = neopixel.NeoPixel(machine.Pin(p), n)
tm =0.5

def clear():
  for i in range(n):
    np[i] = (0, 0, 0)
    np.write()

np[0] = (255, 0, 0) # set to red, full brightness
np[1] = (0, 128, 0) # set to green, half brightness
np[2] = (0, 0, 64)  # set to blue, quarter brightness

np.write()

