# Complete project details at https://RandomNerdTutorials.com

import time
from umqtt.simple import MQTTClient
#from umqtt.robust import MQTTClient

class TemperatureClient:
	"""
	Represents an MQTT client which publishes temperature data on an interval
	"""

	def __init__(self, client_id, mqtt_server, pin = 0, topic_sub = None, topic_pub = None,will = None, **kwargs):
		"""
		Instantiates a MQTTClient; connects to the MQTT broker.
		Arguments `mqtt_server` and `client_id` are required.

		:param client_id: Unique MQTT client ID
		:type client_id: str
		:param mqtt_server: MQTT broker domain name / IP
		:type server: str
		:param pin: 1-Wire bus pin
		:type pin: int
		:param fahrenheit: Whether or not to publish temperature in Fahrenheit
		:type fahrenheit: bool
		:param topic: Topic to publish temperature on
		:type topic: str
		:param kwargs: Arguments for MQTTClient constructor
		"""
		
		self.client = MQTTClient(client_id, mqtt_server, **kwargs)
		
		if not topic_pub:
			self.topic_pub = b'oficina/%s' % self.client.client_id
		else:
			self.topic_pub = topic_pub
		
		self.client.set_callback(self.sub_cb)
		self.client.set_last_will(b'will/' + client_id,b'reset')
		self.client.connect()

		
		if not topic_sub:
			self.topic_sub = b'notification'
		else:
			self.topic_sub = topic_sub
		
		self.client.subscribe(self.topic_sub)
		self.pin = pin	
		self.last_message = 0
		self.message_interval = 5
		self.counter = 0
		self.msg =b'arepas'

	def publishTemperature(self):
		"""
		Reads the current temperature and publishes it on the configured topic.
		"""
		self.client.publish(self.topic_pub, self.msg)
		
	def start(self):
		"""
		Begins to publish temperature data on an interval (in seconds).
		This function will not exit! Consider using deep sleep instead.
		:param interval: How often to publish temperature data (60s default)
		:type interval: int
		"""
		while True:
			try:
				self.client.check_msg()
				if (time.time() - self.last_message) > self.message_interval:
					self.msg = b'Hello #%d' % self.counter
					self.publishTemperature()
					self.last_message = time.time()
					self.counter += 1
			except KeyboardInterrupt:
				print('Ctrl-C pressed...exiting')
				self.client.disconnect()
				restart_and_reconnect()
	
	def sub_cb(self,topic, msg):
		if topic == b'notification' and msg == b'received':
			print('ESP received hello message')

	@staticmethod	
	def restart_and_reconnect():
		print('Failed to connect to MQTT broker. Reconnecting...')
		time.sleep(10)
		machine.reset()


