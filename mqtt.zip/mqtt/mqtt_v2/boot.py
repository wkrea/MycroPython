import ubinascii
import machine
import esp
esp.osdebug(None)
import gc
gc.collect()

def connect():
	import network
	station = network.WLAN(network.STA_IF)
	station.active(True)
	station.connect(ssid, password)

	while station.isconnected() == False:
	  pass

	print('Connection successful')
	print(station.ifconfig())
# WIFI AND MQTT
ssid = 'HUAWEI'
password = '+36+wifi'
mqtt_server = '192.168.0.44'

# MQTT PARAMETROS
client_id = ubinascii.hexlify(machine.unique_id())
topic_sub = b'notification'
topic_pub = b'oficina'


connect()



