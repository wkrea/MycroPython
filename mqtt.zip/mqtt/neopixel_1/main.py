import machine, neopixel
import time
# number of pixels
n = 12
# strip control gpio
p = 14
np = neopixel.NeoPixel(machine.Pin(p), n)
tm =0.5
def clear():
  for i in range(n):
    np[i] = (0, 0, 0)
    np.write()

while True:
  # ciclo >>>
  for i in range(0,n):
    if i>0:
      np[i-1]=(0, 0, 0)
    np[i]=(128,0,0)
    np.write()
    time.sleep(tm)
  #ciclo <<
  for i in range(0,12):
    if 1-i <= 0:
      np[12-i] = (0, 0, 0)
    np[11-i] = (128,0,0)
    np.write()
    time.sleep(tm)
   
  clear()
  time.sleep(tm)
    
  
  
